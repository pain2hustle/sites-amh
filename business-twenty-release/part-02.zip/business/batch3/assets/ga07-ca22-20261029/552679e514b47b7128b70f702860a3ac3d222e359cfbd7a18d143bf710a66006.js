(()=>{'use strict';
const root=document.documentElement;root.classList.add('cg-js');
const toggle=document.getElementById('menuToggle'),menu=document.getElementById('mobileMenu');
function closeMenu(){if(!menu||!toggle)return;menu.hidden=true;menu.classList.remove('open');toggle.classList.remove('open');toggle.setAttribute('aria-expanded','false');}
toggle?.addEventListener('click',()=>{const open=toggle.getAttribute('aria-expanded')!=='true';menu.hidden=!open;menu.classList.toggle('open',open);toggle.classList.toggle('open',open);toggle.setAttribute('aria-expanded',String(open));});
menu?.addEventListener('click',e=>{if(e.target.closest('a'))closeMenu();});
document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeMenu();toggle?.focus();}});
const hoursData=document.getElementById('business-hours-data');let H=null;try{H=hoursData?JSON.parse(hoursData.textContent):null}catch(e){};
function updateHours(now=new Date()) {let status='Hours not verified',open=null;try{if(H){const p=Object.fromEntries(new Intl.DateTimeFormat('en-US',{timeZone:H.timezone,weekday:'short',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(now).map(x=>[x.type,x.value]));const day=p.weekday.toLowerCase(),m=Number(p.hour)*60+Number(p.minute);if(!Array.isArray(H.hours[day])||!Number.isFinite(m))throw Error('time');open=H.hours[day].some(([a,b])=>{let t=x=>Number(x.slice(0,2))*60+Number(x.slice(3));return m>=t(a)&&m<t(b)});status=open?'Open':'Closed';}}catch(e){open=null;status='Hours not verified'}document.querySelectorAll('[data-open-now]').forEach(el=>{el.classList.toggle('is-open',open===true);el.classList.toggle('is-closed',open===false);el.querySelector('.on-text').textContent=status;el.title=H?'Based on regular business-published hours; holidays may differ.':'Check current hours before visiting.';});}
updateHours();setInterval(updateHours,60000);
const film=document.getElementById('film'),scenes=Array.from(film?.querySelectorAll('.fs')||[]),motion=matchMedia('(prefers-reduced-motion:reduce)'),button=document.getElementById('filmToggle');let paused=false,frame=0;
function paint(){frame=0;if(!film||!scenes.length)return;const r=film.getBoundingClientRect(),range=Math.max(1,film.offsetHeight-innerHeight),p=Math.min(1,Math.max(0,-r.top/range)),i=motion.matches?0:Math.min(scenes.length-1,Math.floor(p*scenes.length*1.0001)),visible=r.bottom>0&&r.top<innerHeight&&!document.hidden;
 scenes.forEach((scene,j)=>{const active=j===i;scene.classList.toggle('on',active);scene.setAttribute('aria-hidden',String(!active));const v=scene.querySelector('video');if(!v)return;if(active&&visible&&!paused&&!motion.matches){v.preload='auto';if(v.paused){const promise=v.play();promise?.catch(()=>{});}}else v.pause();});
 film.style.setProperty('--fp',(p*100).toFixed(1)+'%');film.classList.toggle('past-logo',-r.top>innerHeight*.18);const n=film.querySelector('.fm-n');if(n)n.textContent=String(i+1).padStart(2,'0');}
function queue(){if(!frame)frame=requestAnimationFrame(paint);}
button?.addEventListener('click',()=>{paused=!paused;button.textContent=paused?'Play motion':'Pause motion';button.setAttribute('aria-pressed',String(paused));paint();});
addEventListener('scroll',queue,{passive:true});addEventListener('resize',queue);addEventListener('load',queue);document.addEventListener('visibilitychange',queue);motion.addEventListener?.('change',queue);paint();
document.querySelectorAll('video').forEach(v=>v.addEventListener('error',()=>{v.hidden=true;}));
})();
