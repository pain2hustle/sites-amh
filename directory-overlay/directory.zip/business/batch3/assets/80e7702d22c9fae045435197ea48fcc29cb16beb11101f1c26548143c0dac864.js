(function(root){
 'use strict';
 const dayNames=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
 const unavailable=()=>({state:'unknown',text:'Hours unavailable'});
 function minute(value,closing){
  if(typeof value!=='string'||!/^\d\d:\d\d$/.test(value))return null;
  const [h,m]=value.split(':').map(Number);
  return m<60&&h>=0&&(h<24||(closing&&h===24&&m===0))?h*60+m:null;
 }
 function calculate(config,date){
  if(!config||config.verified!==true||typeof config.timezone!=='string'||!config.weekly)return unavailable();
  const week=[];
  for(let d=0;d<7;d++){
   const intervals=config.weekly[d];if(!Array.isArray(intervals))return unavailable();
   week[d]=[];
   for(const pair of intervals){
    if(!Array.isArray(pair)||pair.length!==2)return unavailable();
    const a=minute(pair[0],false),b=minute(pair[1],true);
    if(a===null||b===null||a===b)return unavailable();week[d].push([a,b]);
   }
  }
  try{
   const when=date instanceof Date?date:new Date(date===undefined?Date.now():date);
   if(!Number.isFinite(when.getTime()))return unavailable();
   const parts=new Intl.DateTimeFormat('en-US',{timeZone:config.timezone,weekday:'short',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(when);
   const get=t=>parts.find(p=>p.type===t)?.value;
   const day=dayNames.indexOf(get('weekday')),now=(Number(get('hour'))%24)*60+Number(get('minute'));
   if(day<0||!Number.isFinite(now))return unavailable();
   const current=week[day].some(([a,b])=>b>a?now>=a&&now<b:now>=a);
   const carry=week[(day+6)%7].some(([a,b])=>b<a&&now<b);
   const state=current||carry?'open':'closed';
   return {state,text:(state==='open'?'Open now':'Closed now')+(config.appointmentOnly?' · Appointment only':'')};
  }catch{return unavailable();}
 }
 function paint(doc,status){
  doc.querySelectorAll('[data-hours-indicator], [data-open-now], [data-amh-hours-state]').forEach(el=>{
   el.setAttribute('data-hours-state',status.state);
   if(el.hasAttribute('data-amh-hours-state'))el.setAttribute('data-amh-hours-state',status.state);
   ['open','closed','unknown'].forEach(k=>el.classList.toggle('is-'+k,status.state===k));
   el.querySelectorAll('[data-hours-label], .on-text, [data-amh-hours-status]').forEach(label=>{if(label.textContent!==status.text)label.textContent=status.text;});
  });
 }
 const api={calculate,paint};
 if(typeof module==='object'&&module.exports)module.exports=api;
 if(!root.document)return;
 root.AMHHours=api;
 function start(){
  const node=root.document.getElementById('amh-hours-config');let config;
  try{config=JSON.parse(node?.textContent||'null');}catch{config=null;}
  const refresh=()=>paint(root.document,calculate(config,new Date()));
  refresh();root.setInterval(refresh,30000);
  root.document.addEventListener('visibilitychange',()=>{if(!root.document.hidden)refresh();});
  root.addEventListener('pageshow',refresh);
 }
 if(root.document.readyState==='loading')root.document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})(typeof window==='object'?window:globalThis);
